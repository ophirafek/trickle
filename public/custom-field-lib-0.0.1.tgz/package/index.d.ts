/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="custom-field-lib" />
export * from './public-api';
