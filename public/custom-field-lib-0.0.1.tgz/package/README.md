# CustomFieldLib

This library was generated with [Angular CLI](https://github.com/angular/angular-cli) version 18.2.0.

## Code scaffolding

Run `ng generate component component-name --project custom-field-lib` to generate a new component. You can also use `ng generate directive|pipe|service|class|guard|interface|enum|module --project custom-field-lib`.
> Note: Don't forget to add `--project custom-field-lib` or else it will be added to the default project in your `angular.json` file. 

## Build

Run `ng build custom-field-lib` to build the project. The build artifacts will be stored in the `dist/` directory.

## Publishing

After building your library with `ng build custom-field-lib`, go to the dist folder `cd dist/custom-field-lib` and run `npm publish`.

## Running unit tests

Run `ng test custom-field-lib` to execute the unit tests via [Karma](https://karma-runner.github.io).

## Further help

To get more help on the Angular CLI use `ng help` or go check out the [Angular CLI Overview and Command Reference](https://angular.dev/tools/cli) page.
