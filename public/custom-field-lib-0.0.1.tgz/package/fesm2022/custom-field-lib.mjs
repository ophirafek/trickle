import * as i0 from '@angular/core';
import { Injectable, Component } from '@angular/core';
import { of } from 'rxjs';
import { catchError } from 'rxjs/operators';
import * as i1 from '@angular/common/http';

class CustomFieldService {
    http;
    //private apiUrl = `${environment.apiUrl}/api/customfields`;
    apiUrl;
    constructor(http) {
        this.http = http;
        this.apiUrl = '';
    }
    // Group operations
    getAllGroups() {
        return this.http.get(`${this.apiUrl}/groups`)
            .pipe(catchError(this.handleError('getAllGroups', [])));
    }
    getGroupsByEntityType(entityType) {
        return this.http.get(`${this.apiUrl}/groups/entity/${entityType}`)
            .pipe(catchError(this.handleError(`getGroupsByEntityType entityType=${entityType}`, [])));
    }
    getGroupById(id) {
        return this.http.get(`${this.apiUrl}/groups/${id}`)
            .pipe(catchError(this.handleError(`getGroupById id=${id}`)));
    }
    saveGroup(group) {
        return this.http.post(`${this.apiUrl}/groups`, group)
            .pipe(catchError(this.handleError('saveGroup')));
    }
    deleteGroup(id) {
        return this.http.delete(`${this.apiUrl}/groups/${id}`)
            .pipe(catchError(this.handleError(`deleteGroup id=${id}`)));
    }
    updateGroupSortOrder(groupIds) {
        return this.http.put(`${this.apiUrl}/groups/sort-order`, groupIds)
            .pipe(catchError(this.handleError('updateGroupSortOrder')));
    }
    checkGroupNameExists(entityType, name, excludeId) {
        let url = `${this.apiUrl}/groups/check-name/${entityType}/${name}`;
        if (excludeId) {
            url += `?excludeId=${excludeId}`;
        }
        return this.http.get(url)
            .pipe(catchError(this.handleError('checkGroupNameExists', false)));
    }
    // Definition operations
    getAllDefinitions() {
        return this.http.get(`${this.apiUrl}/definitions`)
            .pipe(catchError(this.handleError('getAllDefinitions', [])));
    }
    getDefinitionsByEntityType(entityType) {
        return this.http.get(`${this.apiUrl}/definitions/entity/${entityType}`)
            .pipe(catchError(this.handleError(`getDefinitionsByEntityType entityType=${entityType}`, [])));
    }
    getDefinitionsByEntityTypeGrouped(entityType) {
        return this.http.get(`${this.apiUrl}/definitions/entity/${entityType}/grouped`)
            .pipe(catchError(this.handleError(`getDefinitionsByEntityTypeGrouped entityType=${entityType}`, [])));
    }
    getDefinitionsByGroupId(groupId) {
        return this.http.get(`${this.apiUrl}/definitions/group/${groupId}`)
            .pipe(catchError(this.handleError(`getDefinitionsByGroupId groupId=${groupId}`, [])));
    }
    getDefinitionById(id) {
        return this.http.get(`${this.apiUrl}/definitions/${id}`)
            .pipe(catchError(this.handleError(`getDefinitionById id=${id}`)));
    }
    saveDefinition(definition) {
        return this.http.post(`${this.apiUrl}/definitions`, definition)
            .pipe(catchError(this.handleError('saveDefinition')));
    }
    deleteDefinition(id) {
        return this.http.delete(`${this.apiUrl}/definitions/${id}`)
            .pipe(catchError(this.handleError(`deleteDefinition id=${id}`)));
    }
    updateDefinitionSortOrder(fieldIds) {
        return this.http.put(`${this.apiUrl}/definitions/sort-order`, fieldIds)
            .pipe(catchError(this.handleError('updateDefinitionSortOrder')));
    }
    checkFieldNameExists(entityType, name, excludeId) {
        let url = `${this.apiUrl}/definitions/check-name/${entityType}/${name}`;
        if (excludeId) {
            url += `?excludeId=${excludeId}`;
        }
        return this.http.get(url)
            .pipe(catchError(this.handleError('checkFieldNameExists', false)));
    }
    // Option operations
    getOptionsByField(fieldDefinitionId) {
        return this.http.get(`${this.apiUrl}/options/field/${fieldDefinitionId}`)
            .pipe(catchError(this.handleError(`getOptionsByField fieldDefinitionId=${fieldDefinitionId}`, [])));
    }
    saveOptions(fieldDefinitionId, options) {
        return this.http.post(`${this.apiUrl}/options/field/${fieldDefinitionId}`, options)
            .pipe(catchError(this.handleError('saveOptions', [])));
    }
    updateOptionSortOrder(optionIds) {
        return this.http.put(`${this.apiUrl}/options/sort-order`, optionIds)
            .pipe(catchError(this.handleError('updateOptionSortOrder')));
    }
    // Value operations
    getValuesByEntity(entityType, entityId) {
        return this.http.get(`${this.apiUrl}/values/entity/${entityType}/${entityId}`)
            .pipe(catchError(this.handleError(`getValuesByEntity entityType=${entityType}, entityId=${entityId}`, [])));
    }
    getFieldsWithValuesByEntity(entityType, entityId) {
        return this.http.get(`${this.apiUrl}/entity/${entityType}/${entityId}`)
            .pipe(catchError(this.handleError(`getFieldsWithValuesByEntity entityType=${entityType}, entityId=${entityId}`, [])));
    }
    getFieldsWithValuesByEntityGrouped(entityType, entityId) {
        return this.http.get(`${this.apiUrl}/entity/${entityType}/${entityId}/grouped`)
            .pipe(catchError(this.handleError(`getFieldsWithValuesByEntityGrouped entityType=${entityType}, entityId=${entityId}`, [])));
    }
    saveValues(values) {
        return this.http.post(`${this.apiUrl}/values`, values)
            .pipe(catchError(this.handleError('saveValues', [])));
    }
    // Helper methods
    handleError(operation = 'operation', result) {
        return (error) => {
            console.error(`${operation} failed: ${error.message}`);
            console.error(error);
            // Let the app keep running by returning an empty result
            return of(result);
        };
    }
    // Utility methods for common operations
    getFieldTypes() {
        return [
            'text',
            'textarea',
            'number',
            'date',
            'boolean',
            'select',
            'multi-select',
            'general-code'
        ];
    }
    getFieldTypeLabel(type) {
        const labels = {
            'text': 'Text',
            'textarea': 'Text Area',
            'number': 'Number',
            'date': 'Date',
            'boolean': 'Checkbox',
            'select': 'Select',
            'multi-select': 'Multi-Select',
            'general-code': 'General Code'
        };
        return labels[type] || type;
    }
    getDefaultValueForType(type) {
        switch (type) {
            case 'text':
            case 'textarea':
                return '';
            case 'number':
                return null;
            case 'date':
                return null;
            case 'boolean':
                return false;
            case 'select':
                return null;
            case 'multi-select':
                return [];
            case 'general-code':
                return null;
            default:
                return null;
        }
    }
    createEmptyGroup(entityType) {
        return {
            id: 0,
            entityType: entityType,
            name: '',
            displayName: '',
            description: '',
            sortOrder: 0,
            isActive: true,
            fields: []
        };
    }
    createEmptyDefinition(entityType, groupId) {
        return {
            id: 0,
            entityType: entityType,
            name: '',
            displayName: '',
            description: '',
            fieldType: 'text',
            isRequired: false,
            isActive: true,
            sortOrder: 0,
            defaultValue: null,
            minValue: null,
            maxValue: null,
            maxLength: null,
            regex: null,
            options: [],
            generalCodeType: null,
            groupId: groupId || null,
            groupName: 'General',
            isVisible: true
        };
    }
    createEmptyOption(fieldDefinitionId) {
        return {
            id: 0,
            fieldDefinitionId: fieldDefinitionId,
            value: '',
            displayText: '',
            sortOrder: 0,
            isActive: true
        };
    }
    createEmptyValue(entityType, entityId, fieldDefinitionId, fieldType) {
        const value = {
            id: 0,
            entityId: entityId,
            entityType: entityType,
            fieldDefinitionId: fieldDefinitionId,
            textValue: '',
            numberValue: null,
            dateValue: null,
            booleanValue: false,
            selectedOptionIds: []
        };
        // Initialize the appropriate value property based on field type
        switch (fieldType) {
            case 'text':
            case 'textarea':
                value.textValue = '';
                break;
            case 'number':
            case 'select':
            case 'general-code':
                value.numberValue = null;
                break;
            case 'date':
                value.dateValue = null;
                break;
            case 'boolean':
                value.booleanValue = false;
                break;
            case 'multi-select':
                value.selectedOptionIds = [];
                break;
        }
        return value;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: CustomFieldService, deps: [{ token: i1.HttpClient }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: CustomFieldService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: CustomFieldService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }] });

var CustomFieldType;
(function (CustomFieldType) {
    CustomFieldType["TEXT"] = "text";
    CustomFieldType["NUMBER"] = "number";
    CustomFieldType["DATE"] = "date";
    CustomFieldType["BOOLEAN"] = "boolean";
    CustomFieldType["SELECT"] = "select";
    CustomFieldType["MULTI_SELECT"] = "multi-select";
    CustomFieldType["GENERAL_CODE"] = "general-code";
    CustomFieldType["TEXTAREA"] = "textarea";
})(CustomFieldType || (CustomFieldType = {}));

class CustomFieldLibComponent {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: CustomFieldLibComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.13", type: CustomFieldLibComponent, isStandalone: true, selector: "lib-custom-field-lib", ngImport: i0, template: `
    <p>
      custom-field-lib works!
    </p>
  `, isInline: true, styles: [""] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: CustomFieldLibComponent, decorators: [{
            type: Component,
            args: [{ selector: 'lib-custom-field-lib', standalone: true, imports: [], template: `
    <p>
      custom-field-lib works!
    </p>
  ` }]
        }] });

/*
 * Public API Surface of custom-field-lib
 */

/**
 * Generated bundle index. Do not edit.
 */

export { CustomFieldLibComponent, CustomFieldService, CustomFieldType };
//# sourceMappingURL=custom-field-lib.mjs.map
