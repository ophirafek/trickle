import * as i0 from "@angular/core";
export declare class CustomFieldLibComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<CustomFieldLibComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CustomFieldLibComponent, "lib-custom-field-lib", never, {}, {}, never, never, true, never>;
}
