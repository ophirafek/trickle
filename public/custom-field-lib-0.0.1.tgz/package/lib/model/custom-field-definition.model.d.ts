export declare enum CustomFieldType {
    TEXT = "text",
    NUMBER = "number",
    DATE = "date",
    BOOLEAN = "boolean",
    SELECT = "select",
    MULTI_SELECT = "multi-select",
    GENERAL_CODE = "general-code",
    TEXTAREA = "textarea"
}
export interface CustomFieldOption {
    id: number;
    value: string;
    displayText: string;
}
export interface CustomFieldDefinition {
    id: number;
    entityType: string;
    name: string;
    displayName: string;
    description?: string;
    fieldType: CustomFieldType;
    isRequired: boolean;
    isActive: boolean;
    sortOrder: number;
    defaultValue?: any;
    minValue?: number;
    maxValue?: number;
    maxLength?: number;
    regex?: string;
    options?: CustomFieldOption[];
    generalCodeType?: number;
    groupName?: string;
    isVisible: boolean;
    createdDate: Date;
    modifiedDate: Date;
    createdBy: number;
    modifiedBy: number;
}
