export interface CustomFieldValue {
    id?: number;
    entityId: number;
    entityType: string;
    fieldDefinitionId: number;
    textValue?: string;
    numberValue?: number;
    dateValue?: Date;
    booleanValue?: boolean;
    selectedOptionIds?: number[];
    generalCodeValue?: number;
}
